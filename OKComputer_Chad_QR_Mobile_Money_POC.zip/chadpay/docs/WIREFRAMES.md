# ChadPay UI Wireframes

## Design Principles

1. **Mobile-First**: All screens designed for 320px+ width
2. **Low Bandwidth**: Minimal images, CSS via CDN, HTMX for partial updates
3. **French Default**: All UI text in French (Chad's official language)
4. **High Contrast**: Clear visual hierarchy for outdoor/sunlight use
5. **Large Touch Targets**: Minimum 44px for buttons

---

## 1. Customer Payment Page

```
┌─────────────────────────────┐
│  🔷 ChadPay                 │  <- Blue header
├─────────────────────────────┤
│                             │
│  ┌─────┐  Moussa Taxi      │  <- Merchant info
│  │ 🚕  │  Taxi             │     with icon
│  └─────┘  Centre ville      │
│                             │
├─────────────────────────────┤
│  Montant à payer            │
│                             │
│      ┌─────────┐            │  <- Fixed amount for
│      │  500    │            │     transport
│      │  FCFA   │            │
│      └─────────┘            │
│                             │
├─────────────────────────────┤
│  Choisir votre wallet       │
│                             │
│  ┌─────────────────────┐    │  <- Airtel Money
│  │ 🔴 Airtel Money  ✓  │    │     (selected)
│  │    Paiement mobile  │    │
│  └─────────────────────┘    │
│                             │
│  ┌─────────────────────┐    │  <- Moov Cash
│  │ 🔵 Moov Cash        │    │
│  │    Paiement mobile  │    │
│  └─────────────────────┘    │
│                             │
├─────────────────────────────┤
│  ┌─────────────────────┐    │  <- Primary CTA
│  │   Payer maintenant  │    │
│  └─────────────────────┘    │
│                             │
└─────────────────────────────┘
```

**Notes**:
- Amount is preset for transport (300/500 FCFA)
- Vendors show editable amount field
- Wallet selection highlights on tap
- Pay button disabled until wallet selected

---

## 2. Payment Initiated Page (USSD Dialer)

```
┌─────────────────────────────┐
│  🔷 ChadPay                 │
├─────────────────────────────┤
│                             │
│  ①───②───③                 │  <- Progress steps
│  ✓   ●   ○                  │
│                             │
├─────────────────────────────┤
│  Validez le paiement        │
│                             │
│  Montant                    │
│    ┌──────────┐             │
│    │ 500 FCFA │             │  <- Large amount
│    └──────────┘             │
│                             │
│  À                          │
│  Moussa Taxi                │
│  +235 66 44 55 66           │
│                             │
├─────────────────────────────┤
│  Code USSD à composer:      │
│                             │
│  ┌─────────────────────┐    │
│  │ *144*1*66112233*500#│    │  <- USSD code
│  └─────────────────────┘    │
│                             │
│  ┌─────────────────────┐    │  <- Dial button
│  │ 📞 Composer le code │    │     (green)
│  └─────────────────────┘    │
│                             │
├─────────────────────────────┤
│  Instructions:              │
│  1. Cliquez sur "Composer"  │
│  2. Suivez les instructions │
│  3. Confirmez avec PIN      │
│  4. Revenez et cliquez ✓    │
│                             │
├─────────────────────────────┤
│  Votre numéro (optionnel)   │
│  ┌─────────────────────┐    │
│  │ +235 66 XX XX XX    │    │
│  └─────────────────────┘    │
│                             │
│  ┌─────────────────────┐    │  <- Confirmation
│  │    J'ai payé ✓      │    │     (blue)
│  └─────────────────────┘    │
│                             │
└─────────────────────────────┘
```

**Notes**:
- Dial button opens phone dialer with USSD
- Instructions clearly numbered
- Optional phone for confirmation
- "J'ai payé" is the main action after payment

---

## 3. Waiting for Confirmation Page

```
┌─────────────────────────────┐
│  🔷 ChadPay                 │
├─────────────────────────────┤
│                             │
│         ┌─────┐             │
│         │  ✓  │             │  <- Success check
│         └─────┘             │
│                             │
│   Paiement confirmé!        │
│   En attente de validation  │
│                             │
├─────────────────────────────┤
│  Commerçant                 │
│  Moussa Taxi                │
│  ─────────────────────────  │
│  Montant                    │
│  500 FCFA                   │
│                             │
├─────────────────────────────┤
│  ┌─────────────────────┐    │
│  │ ⏳ En attente du    │    │  <- Yellow status
│  │    commerçant...    │    │     box with spinner
│  │    Veuillez patienter   │
│  └─────────────────────┘    │
│                             │
│  (Auto-refreshes every 3s)  │
│                             │
│  ┌─────────────────────┐    │
│  │  Retour à l'accueil │    │
│  └─────────────────────┘    │
│                             │
└─────────────────────────────┘
```

**Notes**:
- HTMX polls every 3 seconds
- Shows spinner animation
- Updates automatically when merchant responds

---

## 4. Merchant Dashboard

```
┌─────────────────────────────┐
│  🟢 Moussa Taxi    Déconnex │  <- Green header
├─────────────────────────────┤
│                             │
│  ┌──────────┐ ┌──────────┐  │
│  │Aujourd'hui│ En attente │  │  <- Stats cards
│  │  500 FCFA │     2      │  │
│  │ 1 trans   │ à confirmer│  │
│  └──────────┘ └──────────┘  │
│                             │
├─────────────────────────────┤
│  Paiements en attente    [2]│  <- Section header
│                             │
│  ┌─────────────────────┐    │
│  │ 500 FCFA        ●   │    │  <- Pending item
│  │ airtel_money 14:32:01    │
│  │ De: +235 66XX XXXX  │    │
│  │                     │    │
│  │ [✓ REÇU] [✗ NON]   │    │  <- Action buttons
│  └─────────────────────┘    │
│                             │
│  ┌─────────────────────┐    │
│  │ 300 FCFA        ●   │    │  <- Second pending
│  │ moov_cash 14:30:45  │    │
│  │                     │    │
│  │ [✓ REÇU] [✗ NON]   │    │
│  └─────────────────────┘    │
│                             │
├─────────────────────────────┤
│  [📋 Historique] [⚙️ QR]   │  <- Quick actions
│                             │
├─────────────────────────────┤
│  Transactions récentes      │
│  ─────────────────────────  │
│  500 FCFA        ✓ Reçu     │
│  14:25 airtel_money         │
│  ─────────────────────────  │
│  300 FCFA        ✓ Reçu     │
│  14:15 moov_cash            │
│                             │
└─────────────────────────────┘
```

**Notes**:
- Green header distinguishes merchant area
- Pending payments at top (priority)
- Two-button confirmation (REÇU / NON REÇU)
- HTMX updates pending list without refresh

---

## 5. Merchant Login

```
┌─────────────────────────────┐
│  🟢 ChadPay   Espace Commerç│
├─────────────────────────────┤
│                             │
│         ┌─────┐             │
│         │ 👤  │             │  <- User icon
│         └─────┘             │
│                             │
│   Connexion Commerçant      │
│                             │
├─────────────────────────────┤
│                             │
│  Numéro de téléphone        │
│  ┌─────────────────────┐    │
│  │ +235 66 XX XX XX    │    │
│  └─────────────────────┘    │
│                             │
│  Code PIN (4 chiffres)      │
│  ┌─────────────────────┐    │
│  │ ****                │    │  <- Numeric input
│  └─────────────────────┘    │
│                             │
│  ┌─────────────────────┐    │
│  │   Se connecter      │    │  <- Green CTA
│  └─────────────────────┘    │
│                             │
│  ← Retour à l'accueil       │
│                             │
└─────────────────────────────┘
```

**Notes**:
- Simple phone + PIN
- Numeric keyboard for PIN
- Clear error messages

---

## 6. Admin Dashboard

```
┌─────────────────────────────┐
│  ⬛ Admin         Déconnex  │  <- Dark header
├─────────────────────────────┤
│                             │
│  ┌──────────┐ ┌──────────┐  │
│  │Commerçants│Aujourd'hui │  │  <- Stats
│  │    15     │   12       │  │
│  │ 12 actifs │ 4500 FCFA  │  │
│  └──────────┘ └──────────┘  │
│                             │
│  ⚠️ 3 paiement(s) en attente│  <- Alert (if any)
│       Voir →                │
│                             │
├─────────────────────────────┤
│  [+] Nouveau   [👥] Liste   │  <- Quick actions
│  [📋] Transac  [📄] Logs    │
│                             │
├─────────────────────────────┤
│  Activité récente           │
│  ─────────────────────────  │
│  [admin] CREATE             │
│  Created merchant: Taxi 001 │
│  ─────────────────────────  │
│  [merchant] LOGIN           │
│  Moussa logged in           │
│                             │
└─────────────────────────────┘
```

---

## 7. Admin - Create Merchant

```
┌─────────────────────────────┐
│  ⬛ ← Retour   Nouveau     │
├─────────────────────────────┤
│                             │
│  Informations du commerçant │
│  ─────────────────────────  │
│                             │
│  Nom *                      │
│  ┌─────────────────────┐    │
│  │                     │    │
│  └─────────────────────┘    │
│                             │
│  Code * (unique)            │
│  ┌─────────────────────┐    │
│  │ TAXI001             │    │
│  └─────────────────────┘    │
│                             │
│  Téléphone *                │
│  ┌─────────────────────┐    │
│  │ +235 66 XX XX XX    │    │
│  └─────────────────────┘    │
│                             │
│  Type *                     │
│  ┌─────────────────────┐    │
│  │ ▼ Taxi (500 FCFA)   │    │  <- Dropdown
│  └─────────────────────┘    │
│                             │
│  Description                │
│  ┌─────────────────────┐    │
│  │                     │    │
│  └─────────────────────┘    │
│                             │
│  ─────────────────────────  │
│  Compte utilisateur         │
│  ─────────────────────────  │
│                             │
│  Nom de l'utilisateur *     │
│  ┌─────────────────────┐    │
│  │                     │    │
│  └─────────────────────┘    │
│                             │
│  Téléphone utilisateur *    │
│  ┌─────────────────────┐    │
│  │                     │    │
│  └─────────────────────┘    │
│                             │
│  Code PIN (4 chiffres) *    │
│  ┌─────────────────────┐    │
│  │ ****                │    │
│  └─────────────────────┘    │
│                             │
│  ┌─────────────────────┐    │
│  │  Créer le commerçant│    │
│  └─────────────────────┘    │
│                             │
└─────────────────────────────┘
```

---

## 8. Admin - Merchant Detail with QR

```
┌─────────────────────────────┐
│  ⬛ ← Retour   Détails      │
├─────────────────────────────┤
│                             │
│  ┌─────┐ Moussa Taxi       │
│  │  M  │ TAXI001           │
│  └─────┘ [Actif]            │
│                             │
│  Type: Taxi                 │
│  Tél: +235 66 44 55 66      │
│  ─────────────────────────  │
│                             │
│  Code QR                    │
│  ┌─────────────────────┐    │
│  │                     │    │
│  │    ┌─────────┐      │    │  <- QR Code
│  │    │ ▓▓▓▓▓▓▓ │      │    │
│  │    │ ▓▓▓▓▓▓▓ │      │    │
│  │    │ ▓▓▓▓▓▓▓ │      │    │
│  │    └─────────┘      │    │
│  │                     │    │
│  │ [Télécharger]       │    │
│  └─────────────────────┘    │
│                             │
│  ─────────────────────────  │
│  Utilisateurs               │
│  Moussa - +235... [Admin]   │
│                             │
│  ─────────────────────────  │
│  Transactions récentes      │
│  500 FCFA - 14:25 - Reçu    │
│  Voir tout →                │
│                             │
└─────────────────────────────┘
```

---

## Responsive Breakpoints

| Breakpoint | Width | Adjustments |
|------------|-------|-------------|
| Mobile (default) | 320px+ | Single column, full-width buttons |
| Tablet | 768px+ | Max-width 600px, centered |
| Desktop | 1024px+ | Max-width 800px, centered |

All screens use `max-w-lg mx-auto` for consistent mobile-first experience.
