"""
ChadPay Data Models
-------------------
SQLModel definitions for all database entities.
Includes merchants, payment intents, transactions, and audit logs.
"""

from sqlmodel import SQLModel, Field, Relationship
from typing import Optional, List
from datetime import datetime
from enum import Enum
import hashlib


# ==================== ENUMS ====================

class MerchantType(str, Enum):
    """Types of merchants supported."""
    BUS = "bus"
    MOTO_TAXI = "moto_taxi"
    TAXI = "taxi"
    VENDOR = "vendor"


class PaymentStatus(str, Enum):
    """Payment intent lifecycle states."""
    INITIATED = "initiated"
    CUSTOMER_CONFIRMED = "customer_confirmed"
    MERCHANT_ACCEPTED = "merchant_accepted"
    MERCHANT_REJECTED = "merchant_rejected"
    EXPIRED = "expired"


class WalletType(str, Enum):
    """Supported mobile money wallets."""
    AIRTEL_MONEY = "airtel_money"
    MOOV_CASH = "moov_cash"


class AuditAction(str, Enum):
    """Audit log action types."""
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"
    LOGIN = "login"
    LOGOUT = "logout"
    PAYMENT_INIT = "payment_init"
    PAYMENT_CONFIRM = "payment_confirm"
    PAYMENT_ACCEPT = "payment_accept"
    PAYMENT_REJECT = "payment_reject"


# ==================== MERCHANT ====================

class MerchantBase(SQLModel):
    """Base merchant fields."""
    name: str = Field(index=True, max_length=100)
    code: str = Field(unique=True, index=True, max_length=20)
    phone: str = Field(index=True, max_length=20)
    merchant_type: MerchantType = Field(default=MerchantType.VENDOR)
    is_active: bool = Field(default=True)
    default_amount: Optional[int] = Field(default=None)  # For vendors
    description: Optional[str] = Field(default=None, max_length=255)
    location: Optional[str] = Field(default=None, max_length=100)


class Merchant(MerchantBase, table=True):
    """Merchant table - stores transport operators and vendors."""
    __tablename__ = "merchants"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    # Relationships
    users: List["MerchantUser"] = Relationship(back_populates="merchant")
    payment_intents: List["PaymentIntent"] = Relationship(back_populates="merchant")
    transactions: List["Transaction"] = Relationship(back_populates="merchant")


class MerchantCreate(MerchantBase):
    """Schema for creating a merchant."""
    pass


class MerchantRead(MerchantBase):
    """Schema for reading merchant data."""
    id: int
    created_at: datetime


class MerchantUpdate(SQLModel):
    """Schema for updating merchant (all fields optional)."""
    name: Optional[str] = None
    phone: Optional[str] = None
    is_active: Optional[bool] = None
    default_amount: Optional[int] = None
    description: Optional[str] = None
    location: Optional[str] = None


# ==================== MERCHANT USER ====================

class MerchantUserBase(SQLModel):
    """Base merchant user fields."""
    phone: str = Field(unique=True, index=True, max_length=20)
    name: str = Field(max_length=100)
    is_active: bool = Field(default=True)
    is_admin: bool = Field(default=False)  # Merchant-level admin


class MerchantUser(MerchantUserBase, table=True):
    """Merchant user table - login credentials for merchants."""
    __tablename__ = "merchant_users"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    merchant_id: int = Field(foreign_key="merchants.id")
    pin_hash: str = Field(max_length=255)  # bcrypt hashed
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_login: Optional[datetime] = None
    
    # Relationships
    merchant: Merchant = Relationship(back_populates="users")


class MerchantUserCreate(MerchantUserBase):
    """Schema for creating merchant user."""
    pin: str = Field(max_length=4, min_length=4)  # Plain PIN, will be hashed
    merchant_id: int


class MerchantUserRead(MerchantUserBase):
    """Schema for reading merchant user."""
    id: int
    merchant_id: int
    created_at: datetime
    last_login: Optional[datetime]


# ==================== PAYMENT INTENT ====================

class PaymentIntentBase(SQLModel):
    """Base payment intent fields."""
    amount: int = Field(gt=0)
    wallet_type: WalletType
    status: PaymentStatus = Field(default=PaymentStatus.INITIATED)
    
    # Customer identification (hashed for privacy)
    customer_hash: Optional[str] = Field(default=None, max_length=64)
    # Partial phone mask (e.g., "+235 66XX XXXX")
    customer_phone_mask: Optional[str] = Field(default=None, max_length=20)


class PaymentIntent(PaymentIntentBase, table=True):
    """Payment intent table - tracks payment lifecycle."""
    __tablename__ = "payment_intents"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    merchant_id: int = Field(foreign_key="merchants.id", index=True)
    
    # Unique token for QR code (signed, tamper-proof)
    qr_token: str = Field(unique=True, index=True, max_length=255)
    
    # Idempotency key (prevents duplicate payments)
    idempotency_key: Optional[str] = Field(default=None, index=True, max_length=64)
    
    created_at: datetime = Field(default_factory=datetime.utcnow)
    customer_confirmed_at: Optional[datetime] = None
    merchant_responded_at: Optional[datetime] = None
    expires_at: datetime  # Payment intent expires after N minutes
    
    # IP and user agent for rate limiting/fraud detection
    customer_ip: Optional[str] = Field(default=None, max_length=45)
    user_agent: Optional[str] = Field(default=None, max_length=255)
    
    # Relationships
    merchant: Merchant = Relationship(back_populates="payment_intents")
    transaction: Optional["Transaction"] = Relationship(back_populates="payment_intent")


class PaymentIntentCreate(SQLModel):
    """Schema for creating payment intent."""
    merchant_id: int
    amount: int
    wallet_type: WalletType
    customer_ip: Optional[str] = None
    user_agent: Optional[str] = None


class PaymentIntentRead(PaymentIntentBase):
    """Schema for reading payment intent."""
    id: int
    merchant_id: int
    qr_token: str
    created_at: datetime
    expires_at: datetime


# ==================== TRANSACTION ====================

class TransactionBase(SQLModel):
    """Base transaction fields (immutable record)."""
    amount: int = Field(gt=0)
    wallet_type: WalletType
    status: PaymentStatus
    final_state: bool = Field(default=False)  # True if accepted or rejected


class Transaction(TransactionBase, table=True):
    """Transaction table - permanent record of completed payments."""
    __tablename__ = "transactions"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    payment_intent_id: int = Field(foreign_key="payment_intents.id", unique=True)
    merchant_id: int = Field(foreign_key="merchants.id", index=True)
    
    # Hashed customer identifier (for analytics, not PII)
    customer_hash: Optional[str] = Field(default=None, index=True, max_length=64)
    
    created_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    
    # Dispute tracking
    disputed: bool = Field(default=False)
    dispute_reason: Optional[str] = None
    dispute_resolved_at: Optional[datetime] = None
    
    # Relationships
    payment_intent: PaymentIntent = Relationship(back_populates="transaction")
    merchant: Merchant = Relationship(back_populates="transactions")


class TransactionRead(TransactionBase):
    """Schema for reading transaction."""
    id: int
    merchant_id: int
    payment_intent_id: int
    created_at: datetime
    completed_at: Optional[datetime]


# ==================== AUDIT LOG ====================

class AuditLog(SQLModel, table=True):
    """Audit log table - tracks all significant actions."""
    __tablename__ = "audit_logs"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    
    # Who performed the action
    actor_type: str = Field(max_length=20)  # "admin", "merchant", "customer", "system"
    actor_id: Optional[str] = Field(default=None, max_length=50)
    
    # What was done
    action: AuditAction
    entity_type: str = Field(max_length=50)  # "merchant", "payment", "transaction", etc.
    entity_id: Optional[str] = Field(default=None, max_length=50)
    
    # Details
    description: str = Field(max_length=500)
    old_values: Optional[str] = Field(default=None)  # JSON string
    new_values: Optional[str] = Field(default=None)  # JSON string
    
    # Context
    ip_address: Optional[str] = Field(default=None, max_length=45)
    user_agent: Optional[str] = Field(default=None, max_length=255)
    
    created_at: datetime = Field(default_factory=datetime.utcnow)


class AuditLogCreate(SQLModel):
    """Schema for creating audit log entry."""
    actor_type: str
    action: AuditAction
    entity_type: str
    description: str
    actor_id: Optional[str] = None
    entity_id: Optional[str] = None
    old_values: Optional[str] = None
    new_values: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None


# ==================== SETTINGS ====================

class Settings(SQLModel, table=True):
    """Application settings table (key-value store)."""
    __tablename__ = "settings"
    
    key: str = Field(primary_key=True, max_length=100)
    value: str = Field(max_length=500)
    description: Optional[str] = None
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    updated_by: Optional[str] = None


# ==================== UTILITY FUNCTIONS ====================

def hash_customer_identifier(phone: str, secret: str) -> str:
    """
    Create a one-way hash of customer phone number.
    Used for analytics without storing actual phone numbers.
    """
    return hashlib.sha256(f"{phone}:{secret}".encode()).hexdigest()


def mask_phone_number(phone: str) -> str:
    """
    Create a masked version of phone number for display.
    Example: +235 66987654 -> +235 66XX XXXX
    """
    if len(phone) < 8:
        return "XXXX XXXX"
    
    # Keep country code and first 2-4 digits, mask the rest
    visible = min(6, len(phone) // 2)
    return phone[:visible] + "X" * (len(phone) - visible)
