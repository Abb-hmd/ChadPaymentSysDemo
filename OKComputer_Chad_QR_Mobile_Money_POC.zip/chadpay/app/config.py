"""
ChadPay Configuration
---------------------
Centralized configuration management using Pydantic Settings.
All sensitive values are loaded from environment variables.
"""

from functools import lru_cache
from typing import Optional
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    # App Info
    app_name: str = Field(default="ChadPay", alias="APP_NAME")
    debug: bool = Field(default=False, alias="DEBUG")
    secret_key: str = Field(default="change-me-in-production", alias="SECRET_KEY")
    
    # Database
    database_url: str = Field(default="sqlite:///./chadpay.db", alias="DATABASE_URL")
    
    # Admin
    admin_username: str = Field(default="admin", alias="ADMIN_USERNAME")
    admin_password_hash: str = Field(default="", alias="ADMIN_PASSWORD_HASH")
    
    # USSD Templates (configurable)
    airtel_money_template: str = Field(
        default="*144*1*{merchant_phone}*{amount}#",
        alias="AIRTEL_MONEY_TEMPLATE"
    )
    moov_cash_template: str = Field(
        default="*155*1*{merchant_phone}*{amount}#",
        alias="MOOV_CASH_TEMPLATE"
    )
    
    # QR Security
    qr_signing_key: str = Field(default="change-me", alias="QR_SIGNING_KEY")
    
    # Payment Amounts (XAF)
    bus_fare: int = Field(default=300, alias="BUS_FARE")
    moto_taxi_fare: int = Field(default=300, alias="MOTO_TAXI_FARE")
    taxi_fare: int = Field(default=500, alias="TAXI_FARE")
    
    # Rate Limiting
    confirmation_rate_limit: int = Field(default=30, alias="CONFIRMATION_RATE_LIMIT")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


# Payment amounts lookup
def get_preset_amount(merchant_type: str) -> Optional[int]:
    """Get preset amount for transport merchants."""
    settings = get_settings()
    amounts = {
        "bus": settings.bus_fare,
        "moto_taxi": settings.moto_taxi_fare,
        "taxi": settings.taxi_fare,
    }
    return amounts.get(merchant_type)


def get_ussd_template(wallet_type: str) -> str:
    """Get USSD template for wallet type."""
    settings = get_settings()
    templates = {
        "airtel_money": settings.airtel_money_template,
        "moov_cash": settings.moov_cash_template,
    }
    return templates.get(wallet_type, settings.airtel_money_template)
