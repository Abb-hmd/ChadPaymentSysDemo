"""
ChadPay Audit Logging
---------------------
Comprehensive audit trail for all significant actions.
Logs are immutable and stored in the database.
"""

from typing import Optional
from sqlmodel import Session
from app.models import AuditLog, AuditLogCreate, AuditAction
import json


def log_action(
    session: Session,
    actor_type: str,
    action: AuditAction,
    entity_type: str,
    description: str,
    actor_id: Optional[str] = None,
    entity_id: Optional[str] = None,
    old_values: Optional[dict] = None,
    new_values: Optional[dict] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None
) -> AuditLog:
    """
    Create an audit log entry.
    
    Args:
        session: Database session
        actor_type: "admin", "merchant", "customer", or "system"
        action: The action performed
        entity_type: Type of entity affected
        description: Human-readable description
        actor_id: ID of the actor (optional)
        entity_id: ID of the affected entity (optional)
        old_values: Previous state as dict (optional)
        new_values: New state as dict (optional)
        ip_address: Client IP (optional)
        user_agent: Client user agent (optional)
    
    Returns:
        Created AuditLog entry
    """
    log = AuditLog(
        actor_type=actor_type,
        actor_id=actor_id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        description=description,
        old_values=json.dumps(old_values) if old_values else None,
        new_values=json.dumps(new_values) if new_values else None,
        ip_address=ip_address,
        user_agent=user_agent
    )
    
    session.add(log)
    session.commit()
    session.refresh(log)
    
    return log


def log_payment_initiated(
    session: Session,
    payment_intent_id: str,
    merchant_id: str,
    amount: int,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None
) -> AuditLog:
    """Log payment initiation."""
    return log_action(
        session=session,
        actor_type="customer",
        action=AuditAction.PAYMENT_INIT,
        entity_type="payment_intent",
        entity_id=payment_intent_id,
        description=f"Payment initiated: {amount} XAF",
        new_values={"amount": amount, "merchant_id": merchant_id},
        ip_address=ip_address,
        user_agent=user_agent
    )


def log_payment_confirmed(
    session: Session,
    payment_intent_id: str,
    customer_hash: Optional[str] = None,
    ip_address: Optional[str] = None
) -> AuditLog:
    """Log customer payment confirmation."""
    return log_action(
        session=session,
        actor_type="customer",
        action=AuditAction.PAYMENT_CONFIRM,
        entity_type="payment_intent",
        entity_id=payment_intent_id,
        description="Customer confirmed payment",
        new_values={"customer_hash": customer_hash},
        ip_address=ip_address
    )


def log_payment_accepted(
    session: Session,
    payment_intent_id: str,
    merchant_id: str,
    merchant_user_id: str
) -> AuditLog:
    """Log merchant payment acceptance."""
    return log_action(
        session=session,
        actor_type="merchant",
        actor_id=merchant_user_id,
        action=AuditAction.PAYMENT_ACCEPT,
        entity_type="payment_intent",
        entity_id=payment_intent_id,
        description="Merchant accepted payment",
        new_values={"merchant_id": merchant_id, "status": "accepted"}
    )


def log_payment_rejected(
    session: Session,
    payment_intent_id: str,
    merchant_id: str,
    merchant_user_id: str,
    reason: Optional[str] = None
) -> AuditLog:
    """Log merchant payment rejection."""
    return log_action(
        session=session,
        actor_type="merchant",
        actor_id=merchant_user_id,
        action=AuditAction.PAYMENT_REJECT,
        entity_type="payment_intent",
        entity_id=payment_intent_id,
        description=f"Merchant rejected payment: {reason or 'No reason given'}",
        new_values={"merchant_id": merchant_id, "status": "rejected", "reason": reason}
    )


def get_recent_audit_logs(
    session: Session,
    limit: int = 100,
    entity_type: Optional[str] = None,
    action: Optional[AuditAction] = None
) -> list:
    """Get recent audit logs with optional filtering."""
    from sqlmodel import select, desc
    
    statement = select(AuditLog).order_by(desc(AuditLog.created_at))
    
    if entity_type:
        statement = statement.where(AuditLog.entity_type == entity_type)
    
    if action:
        statement = statement.where(AuditLog.action == action)
    
    statement = statement.limit(limit)
    
    return session.exec(statement).all()
