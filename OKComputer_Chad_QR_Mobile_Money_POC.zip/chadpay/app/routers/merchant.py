"""
ChadPay Merchant Routes
-----------------------
Merchant dashboard and payment management.
Phone + PIN authentication required.
"""

from fastapi import APIRouter, Request, Depends, HTTPException, Form, Cookie, Response
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlmodel import Session, select, func
from datetime import datetime, date
from typing import Optional

from app.database import get_session
from app.models import (
    Merchant, MerchantUser, PaymentIntent, PaymentStatus, Transaction
)
from app.auth import (
    login_merchant, get_current_merchant_from_token,
    set_auth_cookie, clear_auth_cookie
)
from app.audit import log_payment_accepted, log_payment_rejected

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


def get_current_merchant(
    merchant_token: Optional[str] = Cookie(None),
    session: Session = Depends(get_session)
) -> MerchantUser:
    """Dependency to get current authenticated merchant."""
    if not merchant_token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    user = get_current_merchant_from_token(session, merchant_token)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or expired session")
    
    return user


# ==================== AUTH ROUTES ====================

@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, error: Optional[str] = None):
    """Merchant login page."""
    return templates.TemplateResponse("merchant/login.html", {
        "request": request,
        "error": error
    })


@router.post("/login")
async def login_submit(
    request: Request,
    response: Response,
    phone: str = Form(...),
    pin: str = Form(...),
    session: Session = Depends(get_session)
):
    """Process merchant login."""
    try:
        user, token = login_merchant(session, phone, pin, request)
        set_auth_cookie(response, token, is_admin=False)
        return RedirectResponse(url="/merchant/dashboard", status_code=302)
    except HTTPException as e:
        return templates.TemplateResponse("merchant/login.html", {
            "request": request,
            "error": e.detail
        })


@router.get("/logout")
async def logout(response: Response):
    """Logout merchant."""
    clear_auth_cookie(response, is_admin=False)
    return RedirectResponse(url="/merchant/login", status_code=302)


# ==================== DASHBOARD ====================

@router.get("/dashboard", response_class=HTMLResponse)
async def merchant_dashboard(
    request: Request,
    user: MerchantUser = Depends(get_current_merchant),
    session: Session = Depends(get_session)
):
    """Merchant dashboard - shows pending payments and today's summary."""
    # Get merchant info
    merchant = session.get(Merchant, user.merchant_id)
    
    # Pending confirmations (awaiting merchant response)
    pending_statement = select(PaymentIntent).where(
        PaymentIntent.merchant_id == merchant.id,
        PaymentIntent.status == PaymentStatus.CUSTOMER_CONFIRMED
    ).order_by(PaymentIntent.customer_confirmed_at.desc())
    pending_payments = session.exec(pending_statement).all()
    
    # Today's transactions
    today = date.today()
    today_start = datetime.combine(today, datetime.min.time())
    today_end = datetime.combine(today, datetime.max.time())
    
    today_statement = select(Transaction).where(
        Transaction.merchant_id == merchant.id,
        Transaction.created_at >= today_start,
        Transaction.created_at <= today_end,
        Transaction.status == PaymentStatus.MERCHANT_ACCEPTED
    )
    today_transactions = session.exec(today_statement).all()
    today_total = sum(t.amount for t in today_transactions)
    
    # Recent history (last 20)
    history_statement = select(Transaction).where(
        Transaction.merchant_id == merchant.id
    ).order_by(Transaction.created_at.desc()).limit(20)
    recent_transactions = session.exec(history_statement).all()
    
    return templates.TemplateResponse("merchant/dashboard.html", {
        "request": request,
        "user": user,
        "merchant": merchant,
        "pending_payments": pending_payments,
        "today_count": len(today_transactions),
        "today_total": today_total,
        "recent_transactions": recent_transactions
    })


# ==================== PAYMENT ACTIONS ====================

@router.post("/payment/{payment_intent_id}/accept", response_class=HTMLResponse)
async def accept_payment(
    request: Request,
    payment_intent_id: int,
    user: MerchantUser = Depends(get_current_merchant),
    session: Session = Depends(get_session)
):
    """Merchant accepts a payment (confirms they received it)."""
    # Get payment intent
    payment_intent = session.get(PaymentIntent, payment_intent_id)
    
    if not payment_intent:
        raise HTTPException(status_code=404, detail="Payment not found")
    
    if payment_intent.merchant_id != user.merchant_id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    if payment_intent.status != PaymentStatus.CUSTOMER_CONFIRMED:
        raise HTTPException(status_code=400, detail="Payment not in correct state")
    
    # Update payment intent
    payment_intent.status = PaymentStatus.MERCHANT_ACCEPTED
    payment_intent.merchant_responded_at = datetime.utcnow()
    session.add(payment_intent)
    
    # Create transaction record
    transaction = Transaction(
        payment_intent_id=payment_intent.id,
        merchant_id=payment_intent.merchant_id,
        amount=payment_intent.amount,
        wallet_type=payment_intent.wallet_type,
        status=PaymentStatus.MERCHANT_ACCEPTED,
        final_state=True,
        customer_hash=payment_intent.customer_hash,
        completed_at=datetime.utcnow()
    )
    session.add(transaction)
    session.commit()
    
    # Log acceptance
    log_payment_accepted(
        session=session,
        payment_intent_id=str(payment_intent.id),
        merchant_id=str(merchant.id),
        merchant_user_id=str(user.id)
    )
    
    # Return updated pending list (HTMX)
    merchant = session.get(Merchant, user.merchant_id)
    pending_statement = select(PaymentIntent).where(
        PaymentIntent.merchant_id == merchant.id,
        PaymentIntent.status == PaymentStatus.CUSTOMER_CONFIRMED
    ).order_by(PaymentIntent.customer_confirmed_at.desc())
    pending_payments = session.exec(pending_statement).all()
    
    return templates.TemplateResponse("merchant/partials/pending_list.html", {
        "request": request,
        "pending_payments": pending_payments,
        "merchant": merchant
    })


@router.post("/payment/{payment_intent_id}/reject", response_class=HTMLResponse)
async def reject_payment(
    request: Request,
    payment_intent_id: int,
    reason: Optional[str] = Form(None),
    user: MerchantUser = Depends(get_current_merchant),
    session: Session = Depends(get_session)
):
    """Merchant rejects a payment (did not receive it)."""
    # Get payment intent
    payment_intent = session.get(PaymentIntent, payment_intent_id)
    
    if not payment_intent:
        raise HTTPException(status_code=404, detail="Payment not found")
    
    if payment_intent.merchant_id != user.merchant_id:
        raise HTTPException(status_code=403, detail="Not authorized")
    
    if payment_intent.status != PaymentStatus.CUSTOMER_CONFIRMED:
        raise HTTPException(status_code=400, detail="Payment not in correct state")
    
    # Update payment intent
    payment_intent.status = PaymentStatus.MERCHANT_REJECTED
    payment_intent.merchant_responded_at = datetime.utcnow()
    session.add(payment_intent)
    
    # Create transaction record (as dispute)
    transaction = Transaction(
        payment_intent_id=payment_intent.id,
        merchant_id=payment_intent.merchant_id,
        amount=payment_intent.amount,
        wallet_type=payment_intent.wallet_type,
        status=PaymentStatus.MERCHANT_REJECTED,
        final_state=True,
        customer_hash=payment_intent.customer_hash,
        completed_at=datetime.utcnow(),
        disputed=True,
        dispute_reason=reason or "Payment not received"
    )
    session.add(transaction)
    session.commit()
    
    # Log rejection
    log_payment_rejected(
        session=session,
        payment_intent_id=str(payment_intent.id),
        merchant_id=str(payment_intent.merchant_id),
        merchant_user_id=str(user.id),
        reason=reason
    )
    
    # Return updated pending list (HTMX)
    merchant = session.get(Merchant, user.merchant_id)
    pending_statement = select(PaymentIntent).where(
        PaymentIntent.merchant_id == merchant.id,
        PaymentIntent.status == PaymentStatus.CUSTOMER_CONFIRMED
    ).order_by(PaymentIntent.customer_confirmed_at.desc())
    pending_payments = session.exec(pending_statement).all()
    
    return templates.TemplateResponse("merchant/partials/pending_list.html", {
        "request": request,
        "pending_payments": pending_payments,
        "merchant": merchant
    })


# ==================== TRANSACTION HISTORY ====================

@router.get("/transactions", response_class=HTMLResponse)
async def transaction_history(
    request: Request,
    page: int = 1,
    user: MerchantUser = Depends(get_current_merchant),
    session: Session = Depends(get_session)
):
    """View full transaction history with pagination."""
    per_page = 20
    offset = (page - 1) * per_page
    
    # Get total count
    count_statement = select(func.count(Transaction.id)).where(
        Transaction.merchant_id == user.merchant_id
    )
    total = session.exec(count_statement).first() or 0
    
    # Get transactions
    statement = select(Transaction).where(
        Transaction.merchant_id == user.merchant_id
    ).order_by(Transaction.created_at.desc()).offset(offset).limit(per_page)
    transactions = session.exec(statement).all()
    
    total_pages = (total + per_page - 1) // per_page
    
    return templates.TemplateResponse("merchant/transactions.html", {
        "request": request,
        "user": user,
        "transactions": transactions,
        "page": page,
        "total_pages": total_pages,
        "total": total
    })


# ==================== PROFILE ====================

@router.get("/profile", response_class=HTMLResponse)
async def merchant_profile(
    request: Request,
    user: MerchantUser = Depends(get_current_merchant),
    session: Session = Depends(get_session)
):
    """View merchant profile and QR code."""
    merchant = session.get(Merchant, user.merchant_id)
    
    return templates.TemplateResponse("merchant/profile.html", {
        "request": request,
        "user": user,
        "merchant": merchant
    })
