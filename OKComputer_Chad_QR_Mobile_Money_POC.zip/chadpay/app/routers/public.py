"""
ChadPay Public Routes
---------------------
Customer-facing routes for payment flow.
No authentication required.
"""

from fastapi import APIRouter, Request, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlmodel import Session, select
from datetime import datetime, timedelta

from app.database import get_session
from app.models import (
    Merchant, PaymentIntent, PaymentStatus, WalletType,
    hash_customer_identifier, mask_phone_number
)
from app.config import get_settings, get_preset_amount, get_ussd_template
from app.qr_utils import verify_merchant_token, generate_payment_intent_token, generate_idempotency_key
from app.auth import check_rate_limit
from app.audit import log_payment_initiated, log_payment_confirmed

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")
settings = get_settings()


@router.get("/m/{merchant_code}", response_class=HTMLResponse)
async def merchant_payment_page(
    request: Request,
    merchant_code: str,
    t: str = Query(...),  # Token from QR
    session: Session = Depends(get_session)
):
    """
    Customer payment page - shown when QR code is scanned.
    Verifies QR token and displays payment options.
    """
    # Verify QR token
    is_valid, code_from_token = verify_merchant_token(t)
    
    if not is_valid or code_from_token != merchant_code:
        return templates.TemplateResponse("error.html", {
            "request": request,
            "title": "QR Code Invalide",
            "message": "Ce code QR est invalide ou a expiré. Veuillez scanner un nouveau code."
        })
    
    # Get merchant
    statement = select(Merchant).where(
        Merchant.code == merchant_code,
        Merchant.is_active == True
    )
    merchant = session.exec(statement).first()
    
    if not merchant:
        return templates.TemplateResponse("error.html", {
            "request": request,
            "title": "Commerçant Non Trouvé",
            "message": "Ce commerçant n'existe pas ou n'est plus actif."
        })
    
    # Determine amount options
    preset_amount = get_preset_amount(merchant.merchant_type.value)
    
    return templates.TemplateResponse("payment.html", {
        "request": request,
        "merchant": merchant,
        "preset_amount": preset_amount,
        "wallet_types": [
            {"value": WalletType.AIRTEL_MONEY.value, "label": "Airtel Money", "color": "red"},
            {"value": WalletType.MOOV_CASH.value, "label": "Moov Cash", "color": "blue"}
        ]
    })


@router.post("/m/{merchant_code}/initiate", response_class=HTMLResponse)
async def initiate_payment(
    request: Request,
    merchant_code: str,
    amount: int = Query(..., gt=0),
    wallet_type: str = Query(...),
    session: Session = Depends(get_session)
):
    """
    Initiate payment - creates payment intent and shows USSD dialer.
    """
    # Get merchant
    statement = select(Merchant).where(
        Merchant.code == merchant_code,
        Merchant.is_active == True
    )
    merchant = session.exec(statement).first()
    
    if not merchant:
        raise HTTPException(status_code=404, detail="Merchant not found")
    
    # Validate wallet type
    try:
        wallet = WalletType(wallet_type)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid wallet type")
    
    # Validate amount for transport merchants
    preset = get_preset_amount(merchant.merchant_type.value)
    if preset and amount != preset:
        raise HTTPException(status_code=400, detail="Invalid amount for this merchant type")
    
    # Generate idempotency key
    idempotency_key = generate_idempotency_key(merchant_code, amount, wallet_type)
    
    # Check for existing pending payment with same key
    existing = session.exec(
        select(PaymentIntent).where(
            PaymentIntent.idempotency_key == idempotency_key,
            PaymentIntent.status == PaymentStatus.INITIATED,
            PaymentIntent.expires_at > datetime.utcnow()
        )
    ).first()
    
    if existing:
        payment_intent = existing
    else:
        # Create new payment intent
        payment_intent = PaymentIntent(
            merchant_id=merchant.id,
            amount=amount,
            wallet_type=wallet,
            qr_token=generate_payment_intent_token(),
            idempotency_key=idempotency_key,
            expires_at=datetime.utcnow() + timedelta(minutes=15),
            customer_ip=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent")
        )
        session.add(payment_intent)
        session.commit()
        session.refresh(payment_intent)
        
        # Log initiation
        log_payment_initiated(
            session=session,
            payment_intent_id=str(payment_intent.id),
            merchant_id=str(merchant.id),
            amount=amount,
            ip_address=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent")
        )
    
    # Generate USSD string
    ussd_template = get_ussd_template(wallet_type)
    ussd_string = ussd_template.format(
        merchant_phone=merchant.phone,
        amount=amount
    )
    
    return templates.TemplateResponse("payment_initiated.html", {
        "request": request,
        "merchant": merchant,
        "amount": amount,
        "wallet_type": wallet,
        "ussd_string": ussd_string,
        "payment_intent_id": payment_intent.id
    })


@router.post("/payment/{payment_intent_id}/confirm", response_class=HTMLResponse)
async def confirm_payment(
    request: Request,
    payment_intent_id: int,
    customer_phone: str = Query(default=""),
    session: Session = Depends(get_session)
):
    """
    Customer confirms they have completed payment.
    Rate-limited to prevent abuse.
    """
    # Get payment intent
    payment_intent = session.get(PaymentIntent, payment_intent_id)
    
    if not payment_intent:
        raise HTTPException(status_code=404, detail="Payment not found")
    
    if payment_intent.status != PaymentStatus.INITIATED:
        raise HTTPException(status_code=400, detail="Payment already processed")
    
    if payment_intent.expires_at < datetime.utcnow():
        payment_intent.status = PaymentStatus.EXPIRED
        session.add(payment_intent)
        session.commit()
        raise HTTPException(status_code=400, detail="Payment expired")
    
    # Rate limit check
    ip_key = f"confirm:{request.client.host}"
    allowed, wait_seconds = check_rate_limit(ip_key, settings.confirmation_rate_limit)
    
    if not allowed:
        return templates.TemplateResponse("rate_limited.html", {
            "request": request,
            "wait_seconds": wait_seconds
        })
    
    # Hash customer phone if provided
    customer_hash = None
    phone_mask = None
    if customer_phone:
        customer_hash = hash_customer_identifier(customer_phone, settings.secret_key)
        phone_mask = mask_phone_number(customer_phone)
    
    # Update payment intent
    payment_intent.status = PaymentStatus.CUSTOMER_CONFIRMED
    payment_intent.customer_confirmed_at = datetime.utcnow()
    payment_intent.customer_hash = customer_hash
    payment_intent.customer_phone_mask = phone_mask
    session.add(payment_intent)
    session.commit()
    
    # Log confirmation
    log_payment_confirmed(
        session=session,
        payment_intent_id=str(payment_intent.id),
        customer_hash=customer_hash,
        ip_address=request.client.host if request.client else None
    )
    
    # Get merchant for display
    merchant = session.get(Merchant, payment_intent.merchant_id)
    
    return templates.TemplateResponse("waiting_confirmation.html", {
        "request": request,
        "merchant": merchant,
        "amount": payment_intent.amount,
        "payment_intent_id": payment_intent.id
    })


@router.get("/payment/{payment_intent_id}/status")
async def check_payment_status(
    payment_intent_id: int,
    session: Session = Depends(get_session)
):
    """
    HTMX endpoint to check payment status (polling).
    Returns partial HTML for status updates.
    """
    payment_intent = session.get(PaymentIntent, payment_intent_id)
    
    if not payment_intent:
        return {"status": "not_found"}
    
    return {
        "status": payment_intent.status.value,
        "merchant_accepted": payment_intent.status == PaymentStatus.MERCHANT_ACCEPTED,
        "merchant_rejected": payment_intent.status == PaymentStatus.MERCHANT_REJECTED
    }
