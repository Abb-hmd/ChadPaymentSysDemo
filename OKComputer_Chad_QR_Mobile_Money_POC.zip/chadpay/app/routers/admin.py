"""
ChadPay Admin Routes
--------------------
Admin panel for managing merchants, generating QR codes,
viewing transactions, and exporting reports.
Username + password authentication required.
"""

from fastapi import APIRouter, Request, Depends, HTTPException, Form, Cookie, Response, Query
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from sqlmodel import Session, select, func
from datetime import datetime, date
from typing import Optional, List
import csv
import io
import os

from app.database import get_session
from app.models import (
    Merchant, MerchantUser, MerchantType, PaymentIntent, Transaction, AuditLog
)
from app.config import get_settings, get_preset_amount
from app.auth import login_admin, verify_admin_token, set_auth_cookie, clear_auth_cookie, get_password_hash
from app.qr_utils import generate_qr_code
from app.audit import log_action, AuditAction

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")
settings = get_settings()


def get_current_admin(admin_token: Optional[str] = Cookie(None)) -> bool:
    """Dependency to verify admin authentication."""
    if not admin_token:
        return False
    return verify_admin_token(admin_token)


def require_admin(admin_token: Optional[str] = Cookie(None)):
    """Dependency that raises if not admin."""
    if not verify_admin_token(admin_token or ""):
        raise HTTPException(status_code=401, detail="Admin authentication required")
    return True


# ==================== AUTH ROUTES ====================

@router.get("/login", response_class=HTMLResponse)
async def admin_login_page(request: Request, error: Optional[str] = None):
    """Admin login page."""
    return templates.TemplateResponse("admin/login.html", {
        "request": request,
        "error": error
    })


@router.post("/login")
async def admin_login_submit(
    request: Request,
    response: Response,
    username: str = Form(...),
    password: str = Form(...),
    session: Session = Depends(get_session)
):
    """Process admin login."""
    try:
        token = login_admin(session, username, password, request)
        set_auth_cookie(response, token, is_admin=True)
        return RedirectResponse(url="/admin/dashboard", status_code=302)
    except HTTPException as e:
        return templates.TemplateResponse("admin/login.html", {
            "request": request,
            "error": e.detail
        })


@router.get("/logout")
async def admin_logout(response: Response):
    """Logout admin."""
    clear_auth_cookie(response, is_admin=True)
    return RedirectResponse(url="/admin/login", status_code=302)


# ==================== DASHBOARD ====================

@router.get("/dashboard", response_class=HTMLResponse)
async def admin_dashboard(
    request: Request,
    _: bool = Depends(require_admin),
    session: Session = Depends(get_session)
):
    """Admin dashboard - overview of system."""
    # Statistics
    merchant_count = session.exec(select(func.count(Merchant.id))).first() or 0
    active_merchants = session.exec(
        select(func.count(Merchant.id)).where(Merchant.is_active == True)
    ).first() or 0
    
    # Today's transactions
    today = date.today()
    today_start = datetime.combine(today, datetime.min.time())
    today_end = datetime.combine(today, datetime.max.time())
    
    today_count = session.exec(
        select(func.count(Transaction.id)).where(
            Transaction.created_at >= today_start,
            Transaction.created_at <= today_end,
            Transaction.status == "merchant_accepted"
        )
    ).first() or 0
    
    today_volume = session.exec(
        select(func.sum(Transaction.amount)).where(
            Transaction.created_at >= today_start,
            Transaction.created_at <= today_end,
            Transaction.status == "merchant_accepted"
        )
    ).first() or 0
    
    # Pending confirmations
    pending_count = session.exec(
        select(func.count(PaymentIntent.id)).where(
            PaymentIntent.status == "customer_confirmed"
        )
    ).first() or 0
    
    # Recent audit logs
    audit_logs = session.exec(
        select(AuditLog).order_by(AuditLog.created_at.desc()).limit(10)
    ).all()
    
    return templates.TemplateResponse("admin/dashboard.html", {
        "request": request,
        "stats": {
            "total_merchants": merchant_count,
            "active_merchants": active_merchants,
            "today_transactions": today_count,
            "today_volume": today_volume or 0,
            "pending_confirmations": pending_count
        },
        "audit_logs": audit_logs
    })


# ==================== MERCHANT MANAGEMENT ====================

@router.get("/merchants", response_class=HTMLResponse)
async def list_merchants(
    request: Request,
    page: int = 1,
    search: Optional[str] = None,
    _: bool = Depends(require_admin),
    session: Session = Depends(get_session)
):
    """List all merchants with search."""
    per_page = 20
    offset = (page - 1) * per_page
    
    # Build query
    statement = select(Merchant)
    
    if search:
        statement = statement.where(
            (Merchant.name.contains(search)) |
            (Merchant.code.contains(search)) |
            (Merchant.phone.contains(search))
        )
    
    # Get total
    total = len(session.exec(statement).all())
    
    # Get page
    statement = statement.order_by(Merchant.created_at.desc()).offset(offset).limit(per_page)
    merchants = session.exec(statement).all()
    
    total_pages = (total + per_page - 1) // per_page
    
    return templates.TemplateResponse("admin/merchants.html", {
        "request": request,
        "merchants": merchants,
        "page": page,
        "total_pages": total_pages,
        "search": search,
        "merchant_types": MerchantType
    })


@router.get("/merchants/create", response_class=HTMLResponse)
async def create_merchant_page(
    request: Request,
    _: bool = Depends(require_admin)
):
    """Page to create new merchant."""
    return templates.TemplateResponse("admin/merchant_form.html", {
        "request": request,
        "merchant": None,
        "merchant_types": MerchantType,
        "preset_amounts": {
            "bus": settings.bus_fare,
            "moto_taxi": settings.moto_taxi_fare,
            "taxi": settings.taxi_fare
        }
    })


@router.post("/merchants/create")
async def create_merchant(
    request: Request,
    name: str = Form(...),
    code: str = Form(...),
    phone: str = Form(...),
    merchant_type: str = Form(...),
    user_name: str = Form(...),
    user_phone: str = Form(...),
    user_pin: str = Form(..., min_length=4, max_length=4),
    default_amount: Optional[int] = Form(None),
    description: Optional[str] = Form(None),
    location: Optional[str] = Form(None),
    _: bool = Depends(require_admin),
    session: Session = Depends(get_session)
):
    """Create new merchant with admin user."""
    # Check for duplicate code
    existing = session.exec(select(Merchant).where(Merchant.code == code)).first()
    if existing:
        return templates.TemplateResponse("admin/merchant_form.html", {
            "request": request,
            "error": f"Code '{code}' already exists",
            "merchant": None,
            "merchant_types": MerchantType
        })
    
    # Check for duplicate phone
    existing_phone = session.exec(select(Merchant).where(Merchant.phone == phone)).first()
    if existing_phone:
        return templates.TemplateResponse("admin/merchant_form.html", {
            "request": request,
            "error": f"Phone '{phone}' already registered",
            "merchant": None,
            "merchant_types": MerchantType
        })
    
    # Create merchant
    merchant = Merchant(
        name=name,
        code=code,
        phone=phone,
        merchant_type=MerchantType(merchant_type),
        default_amount=default_amount,
        description=description,
        location=location
    )
    session.add(merchant)
    session.flush()  # Get merchant.id
    
    # Create admin user for merchant
    merchant_user = MerchantUser(
        phone=user_phone,
        name=user_name,
        merchant_id=merchant.id,
        pin_hash=get_password_hash(user_pin),
        is_admin=True
    )
    session.add(merchant_user)
    session.commit()
    
    # Log creation
    log_action(
        session=session,
        actor_type="admin",
        action=AuditAction.CREATE,
        entity_type="merchant",
        entity_id=str(merchant.id),
        description=f"Created merchant: {name} ({code})"
    )
    
    return RedirectResponse(url=f"/admin/merchants/{merchant.id}", status_code=302)


@router.get("/merchants/{merchant_id}", response_class=HTMLResponse)
async def view_merchant(
    request: Request,
    merchant_id: int,
    _: bool = Depends(require_admin),
    session: Session = Depends(get_session)
):
    """View merchant details and QR code."""
    merchant = session.get(Merchant, merchant_id)
    if not merchant:
        raise HTTPException(status_code=404, detail="Merchant not found")
    
    # Get users
    users = session.exec(
        select(MerchantUser).where(MerchantUser.merchant_id == merchant_id)
    ).all()
    
    # Check if QR exists
    qr_path = f"app/static/qr_codes/{merchant.code}.png"
    qr_exists = os.path.exists(qr_path)
    
    # Get recent transactions
    transactions = session.exec(
        select(Transaction).where(
            Transaction.merchant_id == merchant_id
        ).order_by(Transaction.created_at.desc()).limit(10)
    ).all()
    
    return templates.TemplateResponse("admin/merchant_detail.html", {
        "request": request,
        "merchant": merchant,
        "users": users,
        "qr_exists": qr_exists,
        "transactions": transactions
    })


@router.post("/merchants/{merchant_id}/generate-qr")
async def generate_merchant_qr(
    request: Request,
    merchant_id: int,
    base_url: str = Form("http://localhost:8000"),
    _: bool = Depends(require_admin),
    session: Session = Depends(get_session)
):
    """Generate QR code for merchant."""
    merchant = session.get(Merchant, merchant_id)
    if not merchant:
        raise HTTPException(status_code=404, detail="Merchant not found")
    
    # Generate QR code
    qr_bytes, token = generate_qr_code(merchant.code, base_url)
    
    # Save to file
    qr_path = f"app/static/qr_codes/{merchant.code}.png"
    with open(qr_path, "wb") as f:
        f.write(qr_bytes)
    
    # Log action
    log_action(
        session=session,
        actor_type="admin",
        action=AuditAction.UPDATE,
        entity_type="merchant",
        entity_id=str(merchant.id),
        description=f"Generated QR code for merchant: {merchant.code}"
    )
    
    return templates.TemplateResponse("admin/partials/qr_code.html", {
        "request": request,
        "merchant": merchant,
        "qr_url": f"/static/qr_codes/{merchant.code}.png"
    })


# ==================== TRANSACTIONS ====================

@router.get("/transactions", response_class=HTMLResponse)
async def admin_transactions(
    request: Request,
    page: int = 1,
    merchant_id: Optional[int] = None,
    status: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    _: bool = Depends(require_admin),
    session: Session = Depends(get_session)
):
    """View all transactions with filters."""
    per_page = 50
    offset = (page - 1) * per_page
    
    statement = select(Transaction)
    
    if merchant_id:
        statement = statement.where(Transaction.merchant_id == merchant_id)
    
    if status:
        statement = statement.where(Transaction.status == status)
    
    if date_from:
        from_date = datetime.strptime(date_from, "%Y-%m-%d")
        statement = statement.where(Transaction.created_at >= from_date)
    
    if date_to:
        to_date = datetime.strptime(date_to, "%Y-%m-%d")
        to_date = datetime.combine(to_date.date(), datetime.max.time())
        statement = statement.where(Transaction.created_at <= to_date)
    
    # Get total
    total = len(session.exec(statement).all())
    
    # Get page
    statement = statement.order_by(Transaction.created_at.desc()).offset(offset).limit(per_page)
    transactions = session.exec(statement).all()
    
    # Get merchants for filter dropdown
    merchants = session.exec(select(Merchant).where(Merchant.is_active == True)).all()
    
    total_pages = (total + per_page - 1) // per_page
    
    return templates.TemplateResponse("admin/transactions.html", {
        "request": request,
        "transactions": transactions,
        "merchants": merchants,
        "page": page,
        "total_pages": total_pages,
        "filters": {
            "merchant_id": merchant_id,
            "status": status,
            "date_from": date_from,
            "date_to": date_to
        }
    })


@router.get("/transactions/export")
async def export_transactions(
    format: str = "csv",
    merchant_id: Optional[int] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    _: bool = Depends(require_admin),
    session: Session = Depends(get_session)
):
    """Export transactions to CSV."""
    statement = select(Transaction)
    
    if merchant_id:
        statement = statement.where(Transaction.merchant_id == merchant_id)
    
    if date_from:
        from_date = datetime.strptime(date_from, "%Y-%m-%d")
        statement = statement.where(Transaction.created_at >= from_date)
    
    if date_to:
        to_date = datetime.strptime(date_to, "%Y-%m-%d")
        to_date = datetime.combine(to_date.date(), datetime.max.time())
        statement = statement.where(Transaction.created_at <= to_date)
    
    transactions = session.exec(statement.order_by(Transaction.created_at.desc())).all()
    
    # Get merchant lookup
    merchants = {m.id: m for m in session.exec(select(Merchant)).all()}
    
    # Create CSV
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Header
    writer.writerow([
        "ID", "Date", "Merchant", "Merchant Code", "Amount (XAF)",
        "Wallet", "Status", "Customer Hash", "Disputed"
    ])
    
    # Data
    for t in transactions:
        merchant = merchants.get(t.merchant_id)
        writer.writerow([
            t.id,
            t.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            merchant.name if merchant else "Unknown",
            merchant.code if merchant else "Unknown",
            t.amount,
            t.wallet_type.value,
            t.status.value,
            t.customer_hash[:16] + "..." if t.customer_hash else "N/A",
            "Yes" if t.disputed else "No"
        ])
    
    output.seek(0)
    
    # Generate filename
    filename = f"transactions_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    
    return StreamingResponse(
        io.BytesIO(output.getvalue().encode('utf-8-sig')),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


# ==================== SETTINGS ====================

@router.get("/settings", response_class=HTMLResponse)
async def settings_page(
    request: Request,
    _: bool = Depends(require_admin)
):
    """View and edit system settings."""
    return templates.TemplateResponse("admin/settings.html", {
        "request": request,
        "settings": {
            "bus_fare": settings.bus_fare,
            "moto_taxi_fare": settings.moto_taxi_fare,
            "taxi_fare": settings.taxi_fare,
            "airtel_template": settings.airtel_money_template,
            "moov_template": settings.moov_cash_template
        }
    })


# ==================== AUDIT LOGS ====================

@router.get("/audit-logs", response_class=HTMLResponse)
async def view_audit_logs(
    request: Request,
    page: int = 1,
    entity_type: Optional[str] = None,
    _: bool = Depends(require_admin),
    session: Session = Depends(get_session)
):
    """View system audit logs."""
    per_page = 50
    offset = (page - 1) * per_page
    
    statement = select(AuditLog)
    
    if entity_type:
        statement = statement.where(AuditLog.entity_type == entity_type)
    
    total = len(session.exec(statement).all())
    
    statement = statement.order_by(AuditLog.created_at.desc()).offset(offset).limit(per_page)
    logs = session.exec(statement).all()
    
    total_pages = (total + per_page - 1) // per_page
    
    return templates.TemplateResponse("admin/audit_logs.html", {
        "request": request,
        "logs": logs,
        "page": page,
        "total_pages": total_pages
    })
