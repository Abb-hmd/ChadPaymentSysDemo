"""
ChadPay Database Layer
----------------------
SQLite with SQLModel for type-safe ORM operations.
Designed for easy migration to PostgreSQL in production.
"""

from sqlmodel import SQLModel, Session, create_engine, select, Field
from typing import Optional, Generator
from datetime import datetime
from app.config import get_settings

settings = get_settings()

# Engine configuration
# check_same_thread=False for SQLite (FastAPI uses multiple threads)
connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}

engine = create_engine(
    settings.database_url,
    echo=settings.debug,
    connect_args=connect_args
)


def create_db_and_tables():
    """Create all database tables."""
    SQLModel.metadata.create_all(engine)


def get_session() -> Generator[Session, None, None]:
    """Dependency to get database session."""
    with Session(engine) as session:
        yield session


def init_database():
    """Initialize database with required tables."""
    create_db_and_tables()


# ==================== DATABASE SCHEMA ====================
# 
# POSTGRESQL MIGRATION NOTES:
# ---------------------------
# 1. Change DATABASE_URL to postgresql://user:pass@host/dbname
# 2. Remove check_same_thread connect_arg
# 3. Add proper indexing (see below)
# 4. Use UUID instead of auto-increment IDs (optional)
# 5. Add connection pooling with psycopg2
#
# RECOMMENDED INDEXES FOR POSTGRESQL:
# -----------------------------------
# CREATE INDEX idx_merchants_code ON merchants(code);
# CREATE INDEX idx_merchants_phone ON merchants(phone);
# CREATE INDEX idx_merchants_active ON merchants(is_active);
# CREATE INDEX idx_merchant_users_phone ON merchant_users(phone);
# CREATE INDEX idx_payment_intents_merchant ON payment_intents(merchant_id);
# CREATE INDEX idx_payment_intents_status ON payment_intents(status);
# CREATE INDEX idx_payment_intents_created ON payment_intents(created_at);
# CREATE INDEX idx_transactions_merchant ON transactions(merchant_id);
# CREATE INDEX idx_transactions_status ON transactions(status);
# CREATE INDEX idx_transactions_created ON transactions(created_at);
# CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
# CREATE INDEX idx_audit_logs_created ON audit_logs(created_at);
