"""
ChadPay Authentication
----------------------
Simple, secure authentication for merchants (phone + PIN) and admin (username + password).
Uses bcrypt for password hashing and JWT for session management.
"""

from datetime import datetime, timedelta
from typing import Optional, Tuple
from passlib.context import CryptContext
from jose import JWTError, jwt
from fastapi import HTTPException, status, Request
from sqlmodel import Session, select
from app.config import get_settings
from app.models import MerchantUser, AuditAction
from app.audit import log_action

settings = get_settings()

# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT Configuration
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 480  # 8 hours for merchant sessions
ADMIN_TOKEN_EXPIRE_MINUTES = 60    # 1 hour for admin sessions


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a plain password against its hash."""
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    """Generate bcrypt hash of password."""
    return pwd_context.hash(password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create JWT access token."""
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.secret_key, algorithm=ALGORITHM)


def decode_token(token: str) -> Optional[dict]:
    """Decode and validate JWT token."""
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        return None


# ==================== MERCHANT AUTH ====================

def authenticate_merchant(session: Session, phone: str, pin: str) -> Optional[MerchantUser]:
    """
    Authenticate merchant user by phone and PIN.
    Returns user object if valid, None otherwise.
    """
    statement = select(MerchantUser).where(
        MerchantUser.phone == phone,
        MerchantUser.is_active == True
    )
    user = session.exec(statement).first()
    
    if not user:
        return None
    
    if not verify_password(pin, user.pin_hash):
        return None
    
    return user


def login_merchant(session: Session, phone: str, pin: str, request: Request) -> Tuple[MerchantUser, str]:
    """
    Login merchant and create session token.
    Returns (user, token) tuple.
    """
    user = authenticate_merchant(session, phone, pin)
    
    if not user:
        # Log failed login attempt
        log_action(
            session=session,
            actor_type="merchant",
            actor_id=phone,
            action=AuditAction.LOGIN,
            entity_type="merchant_user",
            description=f"Failed login attempt for phone: {phone}",
            ip_address=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent")
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid phone number or PIN"
        )
    
    # Update last login
    user.last_login = datetime.utcnow()
    session.add(user)
    session.commit()
    
    # Create token
    token_data = {
        "sub": str(user.id),
        "phone": user.phone,
        "merchant_id": user.merchant_id,
        "type": "merchant"
    }
    token = create_access_token(
        token_data,
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    
    # Log successful login
    log_action(
        session=session,
        actor_type="merchant",
        actor_id=str(user.id),
        action=AuditAction.LOGIN,
        entity_type="merchant_user",
        entity_id=str(user.id),
        description=f"Merchant {user.name} logged in successfully",
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent")
    )
    
    return user, token


def get_current_merchant_from_token(session: Session, token: str) -> Optional[MerchantUser]:
    """Get merchant user from JWT token."""
    payload = decode_token(token)
    
    if not payload:
        return None
    
    if payload.get("type") != "merchant":
        return None
    
    user_id = payload.get("sub")
    if not user_id:
        return None
    
    statement = select(MerchantUser).where(MerchantUser.id == int(user_id))
    return session.exec(statement).first()


# ==================== ADMIN AUTH ====================

def authenticate_admin(username: str, password: str) -> bool:
    """Authenticate admin credentials."""
    if username != settings.admin_username:
        return False
    
    return verify_password(password, settings.admin_password_hash)


def login_admin(session: Session, username: str, password: str, request: Request) -> str:
    """Login admin and return session token."""
    if not authenticate_admin(username, password):
        # Log failed admin login
        log_action(
            session=session,
            actor_type="admin",
            actor_id=username,
            action=AuditAction.LOGIN,
            entity_type="admin",
            description=f"Failed admin login attempt for: {username}",
            ip_address=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent")
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    
    # Create token
    token_data = {
        "sub": username,
        "type": "admin"
    }
    token = create_access_token(
        token_data,
        expires_delta=timedelta(minutes=ADMIN_TOKEN_EXPIRE_MINUTES)
    )
    
    # Log successful login
    log_action(
        session=session,
        actor_type="admin",
        actor_id=username,
        action=AuditAction.LOGIN,
        entity_type="admin",
        description=f"Admin {username} logged in successfully",
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent")
    )
    
    return token


def verify_admin_token(token: str) -> bool:
    """Verify admin JWT token."""
    payload = decode_token(token)
    
    if not payload:
        return False
    
    return payload.get("type") == "admin"


# ==================== COOKIE HELPERS ====================

def set_auth_cookie(response, token: str, is_admin: bool = False):
    """Set authentication cookie with appropriate settings."""
    max_age = (ADMIN_TOKEN_EXPIRE_MINUTES if is_admin else ACCESS_TOKEN_EXPIRE_MINUTES) * 60
    response.set_cookie(
        key="admin_token" if is_admin else "merchant_token",
        value=token,
        httponly=True,
        max_age=max_age,
        samesite="lax",
        secure=False  # Set to True in production with HTTPS
    )


def clear_auth_cookie(response, is_admin: bool = False):
    """Clear authentication cookie."""
    response.delete_cookie(key="admin_token" if is_admin else "merchant_token")


# ==================== RATE LIMITING ====================

# Simple in-memory rate limit store (use Redis in production)
_rate_limit_store = {}

def check_rate_limit(key: str, window_seconds: int = 30) -> Tuple[bool, int]:
    """
    Check if action is rate limited.
    Returns (allowed, remaining_seconds).
    """
    from time import time
    
    now = time()
    last_attempt = _rate_limit_store.get(key, 0)
    
    if now - last_attempt < window_seconds:
        remaining = int(window_seconds - (now - last_attempt))
        return False, remaining
    
    _rate_limit_store[key] = now
    return True, 0


def clear_rate_limit(key: str):
    """Clear rate limit for a key."""
    _rate_limit_store.pop(key, None)
