"""
ChadPay QR Code Utilities
-------------------------
Generates signed, tamper-proof QR codes for merchants.
QR codes contain a signed token that validates the merchant identity.
"""

import qrcode
import qrcode.image.svg
import hmac
import hashlib
import base64
import uuid
from datetime import datetime, timedelta
from io import BytesIO
from typing import Tuple
from app.config import get_settings

settings = get_settings()


def generate_merchant_token(merchant_code: str) -> str:
    """
    Generate a signed token for merchant QR code.
    Format: base64(merchant_code:timestamp:signature)
    
    The signature prevents QR code tampering - if someone modifies
    the merchant code in the QR, the signature will be invalid.
    """
    timestamp = int(datetime.utcnow().timestamp())
    data = f"{merchant_code}:{timestamp}"
    
    # Create HMAC signature
    signature = hmac.new(
        settings.qr_signing_key.encode(),
        data.encode(),
        hashlib.sha256
    ).hexdigest()[:16]  # Use first 16 chars for shorter QR
    
    # Encode to base64
    token = base64.urlsafe_b64encode(
        f"{data}:{signature}".encode()
    ).decode().rstrip("=")
    
    return token


def verify_merchant_token(token: str) -> Tuple[bool, str]:
    """
    Verify a merchant token from QR code.
    
    Returns:
        (is_valid, merchant_code)
    """
    try:
        # Add padding if needed
        padding = 4 - len(token) % 4
        if padding != 4:
            token += "=" * padding
        
        # Decode
        decoded = base64.urlsafe_b64decode(token.encode()).decode()
        parts = decoded.rsplit(":", 1)
        
        if len(parts) != 2:
            return False, ""
        
        data, received_sig = parts
        merchant_code, timestamp_str = data.rsplit(":", 1)
        
        # Verify signature
        expected_sig = hmac.new(
            settings.qr_signing_key.encode(),
            data.encode(),
            hashlib.sha256
        ).hexdigest()[:16]
        
        if not hmac.compare_digest(received_sig, expected_sig):
            return False, ""
        
        # Check timestamp (QR codes expire after 1 year)
        timestamp = int(timestamp_str)
        token_age = datetime.utcnow().timestamp() - timestamp
        if token_age > 365 * 24 * 60 * 60:  # 1 year
            return False, ""
        
        return True, merchant_code
    
    except Exception:
        return False, ""


def generate_qr_code(
    merchant_code: str,
    base_url: str,
    size: int = 10,
    border: int = 2
) -> Tuple[bytes, str]:
    """
    Generate QR code image for merchant.
    
    Args:
        merchant_code: Unique merchant identifier
        base_url: Base URL for payment page (e.g., https://chadpay.com)
        size: QR module size
        border: QR border size
    
    Returns:
        (png_bytes, token)
    """
    # Generate signed token
    token = generate_merchant_token(merchant_code)
    
    # Create payment URL
    payment_url = f"{base_url}/m/{merchant_code}?t={token}"
    
    # Generate QR code
    qr = qrcode.QRCode(
        version=None,  # Auto-fit
        error_correction=qrcode.constants.ERROR_CORRECT_H,  # High error correction
        box_size=size,
        border=border,
    )
    qr.add_data(payment_url)
    qr.make(fit=True)
    
    # Create PNG image
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Save to bytes
    buffer = BytesIO()
    img.save(buffer, format="PNG")
    png_bytes = buffer.getvalue()
    
    return png_bytes, token


def generate_qr_svg(
    merchant_code: str,
    base_url: str
) -> Tuple[str, str]:
    """
    Generate QR code as SVG string (smaller file size).
    
    Returns:
        (svg_string, token)
    """
    token = generate_merchant_token(merchant_code)
    payment_url = f"{base_url}/m/{merchant_code}?t={token}"
    
    # Generate SVG QR code
    factory = qrcode.image.svg.SvgImage
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=2,
        image_factory=factory
    )
    qr.add_data(payment_url)
    qr.make(fit=True)
    
    # Save to string
    buffer = BytesIO()
    qr.save(buffer)
    svg_string = buffer.getvalue().decode("utf-8")
    
    return svg_string, token


def generate_idempotency_key(merchant_code: str, amount: int, wallet_type: str) -> str:
    """
    Generate idempotency key for payment intent.
    Prevents duplicate payments from same customer in short time window.
    """
    # Round timestamp to 5-minute window
    time_window = int(datetime.utcnow().timestamp()) // (5 * 60)
    
    data = f"{merchant_code}:{amount}:{wallet_type}:{time_window}"
    
    return hashlib.sha256(data.encode()).hexdigest()


def generate_payment_intent_token() -> str:
    """Generate unique payment intent token."""
    return str(uuid.uuid4())
